﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonCommunicationHelper.DTO
{
  public enum ValidationResult
  {
    Sucess = 1,
    failure = 2
  }
}
